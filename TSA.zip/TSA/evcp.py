from flask import Flask, request, jsonify
from datetime import datetime, timedelta

app = Flask(__name__)

# Sample data
charging_points = {
    1: {"id": 1, "location": "Point A", "slots": []},
    2: {"id": 2, "location": "Point B", "slots": []},
}

# Helper function to check slot availability
def is_slot_available(point_id, start_time, end_time):
    for slot in charging_points[point_id]["slots"]:
        if (start_time < slot["end_time"] and end_time > slot["start_time"]):
            return False
    return True

# API to get available charging points
@app.route('/charging_points', methods=['GET'])
def get_charging_points():
    return jsonify(charging_points)

# API to get available slots for a charging point
@app.route('/charging_points/<int:point_id>/slots', methods=['GET'])
def get_available_slots(point_id):
    if point_id not in charging_points:
        return jsonify({"error": "Charging point not found"}), 404
    return jsonify(charging_points[point_id]["slots"])

# API to reserve a slot
@app.route('/charging_points/<int:point_id>/slots', methods=['POST'])
def reserve_slot(point_id):
    if point_id not in charging_points:
        return jsonify({"error": "Charging point not found"}), 404

    data = request.get_json()
    start_time = datetime.strptime(data['start_time'], '%Y-%m-%d %H:%M:%S')
    end_time = datetime.strptime(data['end_time'], '%Y-%m-%d %H:%M:%S')

    if not is_slot_available(point_id, start_time, end_time):
        return jsonify({"error": "Slot is not available"}), 400

    slot = {
        "start_time": start_time,
        "end_time": end_time,
    }
    charging_points[point_id]["slots"].append(slot)
    return jsonify({"message": "Slot reserved successfully"}), 200

# API to cancel a reservation
@app.route('/charging_points/<int:point_id>/slots/cancel', methods=['POST'])
def cancel_reservation(point_id):
    if point_id not in charging_points:
        return jsonify({"error": "Charging point not found"}), 404

    data = request.get_json()
    start_time = datetime.strptime(data['start_time'], '%Y-%m-%d %H:%M:%S')
    end_time = datetime.strptime(data['end_time'], '%Y-%m-%d %H:%M:%S')

    for slot in charging_points[point_id]["slots"]:
        if slot["start_time"] == start_time and slot["end_time"] == end_time:
            charging_points[point_id]["slots"].remove(slot)
            return jsonify({"message": "Reservation cancelled successfully"}), 200

    return jsonify({"error": "Reservation not found"}), 404

if __name__ == '__main__':
    app.run(debug=True)
    from flask import Flask, jsonify, request

app = Flask(__name__)

@app.route('/')
def home():
    return "Welcome to the EV Charging Points Scheduler!"

@app.errorhandler(404)
def page_not_found(e):
    return jsonify({"error": "Not Found", "message": "The requested URL was not found on the server."}), 404

# Example route
@app.route('/example')
def example():
    return "This is an example route."

if __name__ == '__main__':
    app.run(debug=True)