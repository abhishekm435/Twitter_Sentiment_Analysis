from flask import Flask, render_template, request, redirect, url_for
import nltk
from nltk.sentiment.vader import SentimentIntensityAnalyzer
import pandas as pd
import matplotlib.pyplot as plt
import io
import base64

# Download VADER lexicon if not already downloaded
nltk.download('vader_lexicon')

app = Flask(__name__)

# Store recent analyses in a list (each item is a dictionary with text, sentiment, score, and color)
recent_analyses = []

# Sentiment analysis function
def analyze_sentiment(text):
    sid = SentimentIntensityAnalyzer()
    sentiment_scores = sid.polarity_scores(text)
    return sentiment_scores

@app.route('/', methods=['GET', 'POST'])
def home():
    sentiment = None
    score = None
    color = ""
    text = ""

    if request.method == 'POST':
        # Handle new analysis or deletion
        if 'delete_index' in request.form:
            index = int(request.form['delete_index'])
            if 0 <= index < len(recent_analyses):
                recent_analyses.pop(index)
        else:
            # Perform sentiment analysis
            text = request.form['tweet']
            sentiment_scores = analyze_sentiment(text)
            compound_score = sentiment_scores['compound']

            if compound_score >= 0.05:
                sentiment = "Positive"
                color = "green"
            elif compound_score <= -0.05:
                sentiment = "Negative"
                color = "red"
            else:
                sentiment = "Neutral"
                color = "grey"
            score = f"{compound_score:.2f}"

            result = {"text": text, "sentiment": sentiment, "score": score, "color": color}
            recent_analyses.insert(0, result)

            # Keep only the latest 5 analyses
            if len(recent_analyses) > 5:
                recent_analyses.pop()

    return render_template('index.html', recent_analyses=recent_analyses)

@app.route('/upload', methods=['GET', 'POST'])
def upload():
    sentiment_data = {"Positive": 0, "Negative": 0, "Neutral": 0}
    scores = []

    if request.method == 'POST':
        # Handle CSV upload
        uploaded_file = request.files['file']
        if uploaded_file.filename != '':
            # Read CSV into DataFrame
            df = pd.read_csv(uploaded_file)
            if 'text' not in df.columns:
                return "CSV file must contain a 'text' column"

            sid = SentimentIntensityAnalyzer()
            for text in df['text']:
                sentiment_scores = sid.polarity_scores(text)
                compound_score = sentiment_scores['compound']
                scores.append(compound_score)

                # Count sentiment type
                if compound_score >= 0.05:
                    sentiment_data["Positive"] += 1
                elif compound_score <= -0.05:
                    sentiment_data["Negative"] += 1
                else:
                    sentiment_data["Neutral"] += 1

            # Generate the pie chart
            pie_chart = create_pie_chart(sentiment_data)
            histogram = create_histogram(scores)

            return render_template('upload.html', pie_chart=pie_chart, histogram=histogram)

    return render_template('upload.html')

def create_pie_chart(sentiment_data):
    # Generate pie chart as a base64-encoded image
    labels = [f"{key} ({value})" for key, value in sentiment_data.items()]  # Add counts to labels
    sizes = list(sentiment_data.values())
    colors = ['green', 'red', 'grey']
    total_count = sum(sizes)

    plt.figure(figsize=(12, 12))
    plt.pie(sizes, labels=labels, colors=colors, autopct='%1.1f%%', startangle=140)
    plt.title(f"Sentiment Distribution (Total: {total_count})")  # Add total count to the title
    plt.axis('equal')  # Equal aspect ratio ensures the pie chart is circular.

    # Save the pie chart to a byte buffer
    buffer = io.BytesIO()
    plt.savefig(buffer, format='png')
    buffer.seek(0)
    img_base64 = base64.b64encode(buffer.getvalue()).decode()
    plt.close()

    return img_base64

def create_histogram(scores):
    plt.figure(figsize=(8, 4))

    # Split scores into positive and negative groups
    positive_scores = [score for score in scores if score > 0]
    negative_scores = [score for score in scores if score <= 0]

    # Plot positive and negative scores with respective colors
    plt.hist(negative_scores, bins=10, color='red', edgecolor='black', alpha=0.7, label='Negative Scores')
    plt.hist(positive_scores, bins=10, color='green', edgecolor='black', alpha=0.7, label='Positive Scores')

    # Add labels and legend
    plt.title('Sentiment Score Distribution')
    plt.xlabel('Compound Score')
    plt.ylabel('Frequency')
    plt.legend()

    # Save the histogram to a byte buffer
    buffer = io.BytesIO()
    plt.savefig(buffer, format='png')
    buffer.seek(0)
    img_base64 = base64.b64encode(buffer.getvalue()).decode()
    plt.close()

    return img_base64

@app.route('/about')
def about():
    return render_template('about.html')

if __name__ == '__main__':
    app.run(debug=True)
