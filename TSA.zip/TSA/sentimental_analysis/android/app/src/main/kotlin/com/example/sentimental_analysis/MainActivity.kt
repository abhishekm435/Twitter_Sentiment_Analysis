package com.example.sentimental_analysis

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
