import tkinter as tk
from tkinter import filedialog, messagebox

def calculate():
    # ... (calculate function from previous step)

def clear_fields():
    # ... (clear_fields function from previous step)

def save_results():
    try:
        filename = filedialog.asksaveasfilename(defaultextension=".txt", filetypes=[("Text files", "*.txt"), ("All files", "*.*")])
        if filename:
            with open(filename, "w") as file:
                file.write(f"Principal: ${principal_entry.get()}\n")
                file.write(f"Monthly Rate: {rate_entry.get()}%\n")
                file.write(f"Time (months): {time_entry.get()}\n")
                file.write(f"Simple Interest: {interest_label['text']}\n")
                file.write(f"Total Amount: {total_label['text']}\n")
        except Exception as e:
            messagebox.showerror("Error", f"Error saving file: {e}")

window = tk.Tk()
window.title("Simple Interest Calculator")

# ... (input fields, labels, calculate, clear buttons from previous step)

save_button = tk.Button(window, text="Save", command=save_results)
save_button.grid(row=6, column=0, columnspan=2, padx=5, pady=5)

window.mainloop()