import os

def calculate_simple_interest(principal, monthly_rate, time_months):
    """Calculates simple interest with monthly interest rate and time in months."""
    interest = (principal * monthly_rate * time_months) / 100
    return interest

def calculate_total_amount(principal, interest):
    """Calculates total amount (principal + interest)."""
    total_amount = principal + interest
    return total_amount

def get_input():
    """Gets user input for principal, monthly rate, and time (months) with input validation."""
    while True:
        try:
            principal = float(input("Enter the principal amount: "))
            if principal < 0:
                print("Error: Principal amount cannot be negative.")
                continue
            monthly_rate = float(input("Enter the monthly interest rate (%): "))
            if monthly_rate < 0:
                print("Error: Monthly interest rate cannot be negative.")
                continue
            if monthly_rate > 100:
                print("Warning: Monthly interest rate is very high.")
            time_months = float(input("Enter the time period (months): "))
            if time_months < 0:
                print("Error: Time period cannot be negative.")
                continue
            return principal, monthly_rate, time_months
        except ValueError:
            print("Invalid input. Please enter numeric values.")

def main():
    """Main function to run the calculator."""
    while True:
        principal, monthly_rate, time_months = get_input()

        if principal is not None:
            interest = calculate_simple_interest(principal, monthly_rate, time_months)
            total_amount = calculate_total_amount(principal, interest)
            print(f"The simple interest is: ${interest:.2f}")
            print(f"The total amount is: ${total_amount:.2f}")

            save_results = input("Save results to file? (yes/no): ").lower()
            if save_results in ("yes", "y"):
                filename = input("Enter filename to save (e.g., results.txt): ")
                try:
                    with open(filename, "w") as file:
                        file.write(f"Principal: ${principal:.2f}\n")
                        file.write(f"Monthly Rate: {monthly_rate:.2f}%\n")
                        file.write(f"Time (months): {time_months}\n")
                        file.write(f"Simple Interest: ${interest:.2f}\n")
                        file.write(f"Total Amount: ${total_amount:.2f}\n")
                    print(f"Results saved to {filename}")
                except Exception as e:
                    print(f"Error saving file: {e}")

        another_calculation = input("Perform another calculation? (yes/no): ").lower()
        if another_calculation in ("no", "n"):
            break
        os.system('cls' if os.name == 'nt' else 'clear')

if __name__ == "__main__":
    main()
    